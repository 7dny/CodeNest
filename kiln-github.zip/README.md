# Kiln — Code Studio

A static HTML, CSS and JavaScript playground. No installation, build tools, API keys or backend required.

## GitHub Pages

1. Upload `index.html`, `style.css`, and `app.js` to the root of your GitHub repository. These are at the root of the downloadable ZIP, or inside `dist` in the source folder.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Select **main** and **/(root)**, then save.
5. GitHub will display the website address after deployment.

You can also open `dist/index.html` directly in a browser. The optional Google Fonts stylesheet needs internet; system fonts are used otherwise.

## Included

- HTML, CSS and JavaScript editors with line numbers and Tab indentation.
- Live, sandboxed preview; manual run and Ctrl/Cmd+Enter.
- Vertical stack, columns, focus/tabs, individual minimize controls.
- Drag or keyboard-resize the editor/preview split.
- Desktop, tablet and phone preview widths.
- Four editor themes: Carbon, Paper, Midnight and Plum.
- Local autosave of the current project's name and code.
- Named standalone HTML and editable JSON exports.
- Import HTML, CSS, JS or Kiln JSON. Select CSS/JS alongside HTML to replace extracted inline code.
- Console output and runtime errors.


## Notes

This is a lightweight text editor; syntax highlighting and autocomplete are future additions. Autosave stores one current project per browser origin, so export JSON to retain multiple projects. Import replaces corresponding code without a merge. Relative external assets must be hosted at suitable URLs; they are not bundled. The preview isolates code from the editor but allows scripts to load external resources. A full browser page running an infinite loop can still become unresponsive. No server or multi-user storage is included.

